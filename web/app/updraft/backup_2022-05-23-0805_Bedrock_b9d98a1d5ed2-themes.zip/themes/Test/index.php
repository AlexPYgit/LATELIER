
<?php
/**
 * The main template file of test theme
 *
 */
get_header() ?>

<div class="content w-100 ">

 <?php the_content(); ?>
    

</div>

<?php get_footer() ?>