

    <div class="block-container pt-5  m-0 w-100">
        <div style="padding: 0 92px ;">
            <div>
                <div>
                    <h1><?= get_field('title_page') ?></h1>
                </div>
            </div>
            <div>
                <div class="pattern-title">
                    <img width="200" height="96" src="<?= get_template_directory_uri(). '/assets/images/pattern.png' ?>" alt="decoration">
                </div>
            </div>
            <div>
                <div style="position: relative; top:-105px;">
                    <div style="margin: 10px 0 0 150px ; padding-right:20px;" class="col-5">
                        <p><?= get_field('description_page') ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
