
<!-- script for the slider -->
<script type="module"> 

  var slider = tns({
    container: '.my-slider',
    controlsContainer : '#customize-controls',
    autoHeight: true,
    items: 2.5,
    nav: false,
    gutter: '20px',
    swipeAngle: 15,
    speed: 400
  });
  </script>
